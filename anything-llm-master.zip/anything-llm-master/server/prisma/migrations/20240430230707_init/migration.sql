-- AlterTable
ALTER TABLE "workspaces" ADD COLUMN "queryRefusalResponse" TEXT;
