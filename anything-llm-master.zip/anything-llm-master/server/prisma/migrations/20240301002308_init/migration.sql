-- AlterTable
ALTER TABLE "workspaces" ADD COLUMN "pfpFilename" TEXT;
