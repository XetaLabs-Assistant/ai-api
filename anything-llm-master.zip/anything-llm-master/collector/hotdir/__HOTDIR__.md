### What is the "Hot directory"

This is a pre-set file location that documents will be written to when uploaded by AnythingLLM. There is really no need to touch it.